import React from "react";

export const A = () => {
    return (
        <>
        <h1>Testing</h1>
        </>
    )
}   